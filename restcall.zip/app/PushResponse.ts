export interface PushResponse {
  id: String;
  name: String;
  description: String;
}
