import { Component } from '@angular/core';
import {PushResponse} from "./PushResponse";
import {PushService} from "./push.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = '';
pushResponse : PushResponse[];
  constructor(private pushService: PushService){}

  ngOnInit() {
    this
      .pushService
      .getBooks()
      .subscribe((data: PushResponse[]) => {
        this.pushResponse = data;
      });
  }
}
